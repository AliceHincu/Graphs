from ui import ConsoleUI

console = ConsoleUI()