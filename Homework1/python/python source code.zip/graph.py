from copy import deepcopy


class GraphException(Exception):
    def __init__(self, msg):
        super().__init__(msg)


class Graph:
    """A directed graph, represented as two maps,
    one from each vertex to the set of outbound neighbours,
    the other from each vertex to the set of inbound neighbours"""

    def __init__(self, n):
        """Creates a graph with n vertices (numbered from 0 to n-1)
        and no edges"""
        self._dictOut = {}
        self._dictIn = {}
        self._dictCost = {}
        for i in range(n):
            self._dictOut[i] = []
            self._dictIn[i] = []

    def get_number_vertices(self):
        """Returns the number of vertices"""
        return len(self._dictOut.keys())

    def parse_vertices(self):
        """Returns an iterable containing all the vertices"""
        return iter(self._dictOut.keys())

    def is_edge(self, x, y):
        """Returns True if there is an edge from x to y, False otherwise
        Condition: x and y must be valid vertices, else raise exception"""
        if x not in self.parse_vertices() or y not in self.parse_vertices():
            raise GraphException("!!! Invalid vertex")
        if y in self._dictOut[x]:
            return True
        else:
            return False

    def out_degree(self, x):
        """Returns the out degree of a specified vertex
        Condition: x must be a valid vertex, else raise exception"""
        if x not in self.parse_vertices():
            raise GraphException("!!! Invalid vertex")
        return len(self._dictOut[x])

    def parse_vertex_out(self, x):
        """Returns an iterable containing the outbound neighbours of x
        Condition: x must be a valid vertex, else raise exception"""
        if x not in self.parse_vertices():
            raise GraphException("!!! Invalid vertex")
        return iter(self._dictOut[x])

    def in_degree(self, x):
        """Returns the in degree of a specified vertex
        Condition: x must be a valid vertex, else raise exception"""
        if x not in self.parse_vertices():
            raise GraphException("!!! Invalid vertex")
        return len(self._dictIn[x])

    def parse_vertex_in(self, x):
        """Returns an iterable containing the inbound neighbours of x
        Condition: x must be a valid vertex, else raise exception"""
        if x not in self.parse_vertices():
            raise GraphException("!!! Invalid vertex")
        return iter(self._dictIn[x])

    def get_cost(self, x, y):
        """Get the cost of the edge
        Conditions: x, y must be valid vertices and the edge must exist"""
        if x not in self.parse_vertices() or y not in self.parse_vertices():
            raise GraphException("!!! Invalid vertex")
        if not self.is_edge(x, y):
            raise GraphException("!!! The edge does not exist")
        return self._dictCost[(x, y)]

    def modify_cost(self, x, y, v):
        """Modify the cost of an edge
        Conditions: x, y must be valid vertices and the edge must exist"""
        if x not in self.parse_vertices() or y not in self.parse_vertices():
            raise GraphException("!!! Invalid vertex")
        if not self.is_edge(x, y):
            raise GraphException("!!! The edge does not exist")
        self._dictCost[(x, y)] = v

    def add_edge(self, x, y, c):
        """Adds an edge from x to y.
        Conditions: x, y must be valid vertices and the edge must not exist"""
        if x not in self.parse_vertices() or y not in self.parse_vertices():
            raise GraphException("!!! Invalid vertex")
        if self.is_edge(x, y):
            raise GraphException("!!! The edge already exists")

        self._dictOut[x].append(y)
        self._dictIn[y].append(x)
        self._dictCost[(x, y)] = c

    def add_edge_no_condition(self, x, y, c):
        """
        Adds an edge from x to y. We assume the input is correct. We use it for reading from a file
        """
        self._dictOut[x].append(y)
        self._dictIn[y].append(x)
        self._dictCost[(x, y)] = c

    def remove_edge(self, x, y):
        """Removes an edge from x to y.
        Conditions: x, y must be valid vertices and the edge must exist"""
        if x not in self.parse_vertices() or y not in self.parse_vertices():
            raise GraphException("!!! Invalid vertex")
        if not self.is_edge(x, y):
            raise GraphException("!!! The edge does not exist")

        self._dictOut[x].remove(y)
        self._dictIn[y].remove(x)
        del self._dictCost[(x, y)]

    def add_vertex(self, x):
        """Add vertex.
        Condition: the vertex must not exist and must be valid(non-negative)"""
        if x in self.parse_vertices():
            raise GraphException("!!! Vertex already exists")
        if x < 0:
            raise GraphException("!!! Invalid vertex")
        self._dictOut[x] = []
        self._dictIn[x] = []

    def remove_vertex(self, x):
        """Remove vertex.
        Condition: the vertex must exist"""
        if x not in self.parse_vertices():
            raise GraphException("!!! Vertex does not exist")

        # remove traces from dictIn and dictCost
        for vertex in self._dictOut[x]:
            self._dictIn[vertex].remove(x)
            del self._dictCost[(x, vertex)]

        # remove traces from dictOut and dictCost
        for vertex in self._dictIn[x]:
            self._dictOut[vertex].remove(x)
            del self._dictCost[(vertex, x)]

        # remove from dictIn
        del self._dictIn[x]

        # remove from dictOut
        del self._dictOut[x]

    def copy_graph(self):
        """Makes a copy of the graph"""
        return deepcopy(self)

    def print_dict(self):
        """ Additional function, role: to see if other functions are working.
        Prints all 3 dictionaries.
        """
        print(self._dictIn, "\n")
        print(self._dictOut, "\n")
        print(self._dictCost, "\n")

    def sort_dictionaries(self):
        """
        Sort dictionary when reading from a modified file
        """
        for i in self._dictIn.keys():  # sort values for each key
            self._dictIn[i].sort()
        self._dictIn = {key: self._dictIn[key] for key in sorted(self._dictIn.keys())}  # sort keys

        for i in self._dictOut.keys():  # sort values for each key
            self._dictOut[i].sort()
        self._dictOut = {key: self._dictOut[key] for key in sorted(self._dictOut.keys())}  # sort keys

        self._dictCost = {key: self._dictCost[key] for key in sorted(self._dictCost.keys())}  # sort keys


