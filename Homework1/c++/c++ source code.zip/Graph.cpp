//
// Created by Sakura on 3/28/2021.
//

#include <algorithm>
#include <iostream>
#include "Graph.h"
#include "GraphException.h"

//implicit
Graph::Graph(): _n{0} {}

// explicit
Graph::Graph(int n): _n{n} {
    for (int i=0; i<n; i++){
        _dictIn[i] = std::vector<int>();
        _dictOut[i] = std::vector<int>();
    }
}

//copy
Graph::Graph(const Graph &g): _dictIn{g._dictIn}, _dictOut{g._dictOut}, _dictCost{g._dictCost}, _n{g._n}{}

//destructor

int Graph::getNumberOfVertices() const{
    return this->_dictOut.size();
}

int Graph::getCost(int x, int y){
    if (!this->validVertex(x) or !this->validVertex(y))
        throw GraphException("!!! Invalid vertex");
    if (!this->isEdge(x, y))
        throw GraphException("!!! The edge does not exist");

    return this->_dictCost[std::make_pair(x, y)];
}

void Graph::setCost(int x, int y, int c) {
    if (!this->validVertex(x) or !this->validVertex(y))
        throw GraphException("!!! Invalid vertex");
    if (!this->isEdge(x, y))
        throw GraphException("!!! The edge does not exist");
    this->_dictCost[std::make_pair(x, y)] = c;
}

std::pair<std::vector<int>::iterator, std::vector<int>::iterator> Graph::parseVertexIn(int x) {
    if (!this->validVertex(x))
        throw GraphException("!!! Invalid vertex");
    return std::make_pair(this->_dictIn[x].begin(), this->_dictIn[x].end());
}

std::pair<std::vector<int>::iterator, std::vector<int>::iterator> Graph::parseVertexOut(int x) {
    if (!this->validVertex(x))
        throw GraphException("!!! Invalid vertex");
    return std::make_pair(this->_dictOut[x].begin(), this->_dictOut[x].end());
}

std::pair<std::map<int, std::vector<int>>::iterator, std::map<int, std::vector<int>>::iterator> Graph::parseVertices() {
    return std::make_pair(this->_dictOut.begin(), this->_dictOut.end());
}

bool Graph::isEdge(int x, int y) {
    if (!this->validVertex(x) or !this->validVertex(y))
        throw GraphException("!!! Invalid vertex");
    auto ptr = this->parseVertexOut(x);
    if (std::find(ptr.first, ptr.second,y)!=ptr.second)
        return true;
    return false;
}

int Graph::outDegree(int x) {
    if (!this->validVertex(x))
        throw GraphException("!!! Invalid vertex");
    return this->_dictOut[x].size();
}

int Graph::inDegree(int x) {
    if (!this->validVertex(x))
        throw GraphException("!!! Invalid vertex");
    return this->_dictIn[x].size();
}

bool Graph::validVertex(int x) {
    auto it = this->_dictOut.find(x);
    if (it != this->_dictOut.end())
        return true;
    return false;

}

void Graph::addEdge(int x, int y, int c) {
    if (!this->validVertex(x) or !this->validVertex(y))
        throw GraphException("!!! Invalid vertex");
    if (this->isEdge(x, y))
        throw GraphException("!!! The edge already exists");
    this->_dictIn[y].push_back(x);
    this->_dictOut[x].push_back(y);
    this->_dictCost[std::make_pair(x, y)] = c;
}

void Graph::addEdgeNoCondition(int x, int y, int c) {
    this->_dictIn[y].push_back(x);
    this->_dictOut[x].push_back(y);
    this->_dictCost[std::make_pair(x, y)] = c;
}

void Graph::removeEdge(int x, int y) {
    if (!this->validVertex(x) or !this->validVertex(y))
        throw GraphException("!!! Invalid vertex");
    if (!this->isEdge(x, y))
        throw GraphException("!!! The edge does not exist");
    this->_dictIn[y].erase(std::find(this->_dictIn[y].begin(), this->_dictIn[y].end(), x));
    this->_dictOut[x].erase(std::find(this->_dictOut[x].begin(), this->_dictOut[x].end(), y));
    this->_dictCost.erase(std::make_pair(x, y));
}

void Graph::addVertex(int x) {
    if (this->validVertex(x))
        throw GraphException("!!! Vertex already exists");
    if (x < 0)
        throw GraphException("!!! Invalid vertex");

    this->_dictIn[x] = std::vector<int>();
    this->_dictOut[x] = std::vector<int>();
}

void Graph::removeVertex(int x) {
    if (!this->validVertex(x))
        throw GraphException("!!! Vertex does not exist");

    // remove traces from dictIn and dictCost
    auto ptr = this->parseVertexOut(x); // get the outbound set of vertices
    for(auto i = ptr.first; i < ptr.second; i++){
        this->_dictIn[*i].erase(std::find(this->_dictIn[*i].begin(), this->_dictIn[*i].end(), x));
        this->_dictCost.erase(std::make_pair(x, *i));
    }

    // remove traces from dictOut and dictCost
    ptr = this->parseVertexIn(x); // get the inbound set of vertices
    for(auto i = ptr.first; i < ptr.second; i++){
        this->_dictOut[*i].erase(std::find(this->_dictOut[*i].begin(), this->_dictOut[*i].end(), x));
        this->_dictCost.erase(std::make_pair(*i, x));
    }

    // remove from dictIn
    this->_dictIn.erase(x);

    // remove from dictOut
    this->_dictOut.erase(x);
}

Graph::~Graph() {}