//
// Created by Sakura on 3/28/2021.
//

#include "GraphException.h"

#include <utility>

GraphException::GraphException(std::string msg): std::exception(), _msg{std::move(msg)}{}

const std::string &GraphException::get_msg() const {
    return this->_msg;
}

ConsoleException::ConsoleException(std::string msg): std::exception(), _msg{std::move(msg)}{}

const std::string &ConsoleException::get_msg() const {
    return this->_msg;
}
