//
// Created by Sakura on 3/28/2021.
//

#include <iostream>
#include <cassert>
#include "Tests.h"
#include "Graph.h"
#include "GraphException.h"

void Tests::run_all_tests() {
    run_constructor_tests();
}

void Tests::run_constructor_tests() {
    std::cout << "Starting tests\n";

    //implicit
    Graph g;
    assert(g.getNumberOfVertices()==0);

    //explicit
    Graph g2(5);
    assert(g2.getNumberOfVertices()==5);
    g2.addEdge(0, 2, 10);
    auto ptr = g2.parseVertexIn(2);
    for(auto i = ptr.first; i < ptr.second; i++){
        assert(*i == 0);
    }
    ptr = g2.parseVertexOut(0);
    for(auto i = ptr.first; i < ptr.second; i++){
        assert(*i == 2);
    }
    auto ptr2 = g2.parseVertices();
    int vertex = 0;
    for(auto i = ptr2.first; i != ptr2.second; i++){
        assert(i->first == vertex);
        vertex++;
    }
    assert(g2.getCost(0,2) == 10);

    //copy
    Graph g1 = g2;
    assert(g1.getNumberOfVertices()==5);

    //test functions
    assert(g2.isEdge(0, 2)==true);
    assert(g2.isEdge(0,1)==false);
    g2.addEdge(0, 1, 4);
    g2.setCost(0, 1, 3);
    assert(g2.getCost(0, 1) == 3);
    assert(g2.outDegree(0) == 2);
    assert(g2.inDegree(0) == 0);
    assert(g2.validVertex(0)==true);
    assert(g2.validVertex(7)==false);

    //catch exceptions
    try {
        g2.addEdge(7, 6, 10);
    }catch(const GraphException& ve){
        assert(ve.get_msg()=="!!! Invalid vertex");
    }

    try {
        int rez = g2.outDegree(7);
    }catch(const GraphException& ve){
        assert(ve.get_msg()=="!!! Invalid vertex");
    }

    try {
        ptr = g2.parseVertexOut(7);
    }catch(const GraphException& ve){
        assert(ve.get_msg()=="!!! Invalid vertex");
    }

    try {
        int c = g2.getCost(2, 4);
    }catch(const GraphException& ve){
        assert(ve.get_msg()=="!!! The edge does not exist");
    }

    try {
        g2.addEdge(0, 1, 100);
    }catch(const GraphException& ve){
        assert(ve.get_msg()=="!!! The edge already exists");
    }

    g2.removeEdge(0, 1);
    assert(g2.isEdge(0, 1)==false);

    g2.addVertex(8);
    assert(g2.validVertex(8)==true);
    try {
        g2.addVertex(5);
    }catch(const GraphException& ve){
        assert(ve.get_msg()=="!!! Vertex already exists");
    }

    Graph g3{5};
    g3.addEdge(0, 1, 10);
    g3.addEdge(0, 2, 10);
    g3.addEdge(4, 0, 10);
    g3.addEdge(1, 2, 4);
    g3.removeVertex(0);
    assert(g3.validVertex(0) == false);
    assert(g3.inDegree(2)==1);
    assert(g3.outDegree(4)==0);
    std::cout << "Finishing tests\n";
}
