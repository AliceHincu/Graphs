//
// Created by Sakura on 3/28/2021.
//

#ifndef HW1_C___CONSOLE_H
#define HW1_C___CONSOLE_H


#include <string>
#include "Graph.h"

class Console {
private:
    Graph _graph{};
    bool _unicorns_exist;
    std::string _file;

public:
    // implicit constructor
    Console();

    void run();

    void run_read();

    static void print_menu();

    static void print_menu_read();

    void handle_command(const std::string&);

    void handle_command_read(const std::string&);

    void read_file();

    void save_file();

    void generate_graph(int, int);

};


#endif //HW1_C___CONSOLE_H
