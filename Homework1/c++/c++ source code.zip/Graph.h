//
// Created by Sakura on 3/28/2021.
//

#ifndef HW1_C___GRAPH_H
#define HW1_C___GRAPH_H


#include <map>
#include <vector>

class Graph {
private:
    std::map<int, std::vector<int>> _dictIn {};
    std::map<int, std::vector<int>> _dictOut {};
    std::map<std::pair<int, int>, int> _dictCost {};
    int _n; //nr vertices
public:
    //implicit constructor
    Graph();

    //explicit constructor
    explicit Graph(int n);

    //copy constructor
    Graph(const Graph&);

    //getters
    int getNumberOfVertices() const;

    int getCost(int, int);

    //setters
    void setCost(int, int, int);

    // iterator for dictIn
    std::pair <std::vector<int>::iterator, std::vector<int>::iterator> parseVertexIn(int x);

    // iterator for dictOut
    std::pair<std::vector<int>::iterator, std::vector<int>::iterator> parseVertexOut(int x);

    // iterator for vertices
    std::pair<std::map<int, std::vector<int>>::iterator, std::map<int, std::vector<int>>::iterator> parseVertices();

    // functions

    /*Returns True if there is an edge from x to y, False otherwise
    Condition: x and y must be valid vertices, else raise exception*/
    bool isEdge(int, int);

    int inDegree(int);

    int outDegree(int);

    bool validVertex(int);

    void addEdge(int, int, int);

    void addEdgeNoCondition(int, int, int);

    void removeEdge(int, int);

    void addVertex(int);

    void removeVertex(int);
    //destructor
    ~Graph();

};


#endif //HW1_C___GRAPH_H
