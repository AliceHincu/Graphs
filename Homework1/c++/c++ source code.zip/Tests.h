//
// Created by Sakura on 3/28/2021.
//

#ifndef HW1_C___TESTS_H
#define HW1_C___TESTS_H


class Tests {
private:
    static void run_constructor_tests();
public:
    void run_all_tests();
};


#endif //HW1_C___TESTS_H
