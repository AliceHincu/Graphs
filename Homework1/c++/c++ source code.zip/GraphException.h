//
// Created by Sakura on 3/28/2021.
//

#ifndef HW1_C___GRAPHEXCEPTION_H
#define HW1_C___GRAPHEXCEPTION_H


#include <exception>
#include <string>

class GraphException : public std::exception {
private:
    std::string _msg;
public:
    explicit GraphException(std::string  msg);
    const std::string& get_msg() const;
};

class ConsoleException : public std::exception {
private:
    std::string _msg;
public:
    explicit ConsoleException(std::string  msg);
    const std::string& get_msg() const;
};
#endif //HW1_C___GRAPHEXCEPTION_H
