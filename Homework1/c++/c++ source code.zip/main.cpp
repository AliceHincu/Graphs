#include <iostream>
#include "Console.h"
#include "Tests.h"

int main() {
    Console console;
    Tests t;
    t.run_all_tests();
    console.run();
    return 0;
}
