//
// Created by Sakura on 3/28/2021.
//

#include <iostream>
#include <fstream>
#include <cstring>
#include <string>
#include <sstream>
#include "Console.h"
#include "GraphException.h"
using namespace std;

Console::Console(): _unicorns_exist{true} {}

void Console::run() {
    while (this->_unicorns_exist){
        Console::print_menu();
        std::string command;
        std::cout << "\n>>>";
        std::cin >> command;
        try{
            this->handle_command(command);
        }catch(const ConsoleException& ce){
            std::cout << ce.get_msg();
        }
    }
}

void Console::run_read() {
    Console::print_menu_read();
    while (this->_unicorns_exist) {
        std::string command;
        std::cout << "\n>>>";
        std::cin >> command;
        try{
            this->handle_command_read(command);
        }catch(const ConsoleException& ce){
            std::cout << ce.get_msg() << "\n";
        }
    }

}

void Console::print_menu() {
    std::string menu = "~ Menu ~"
                       "\n\t1. Read graph"
                       "\n\t2. Generate graph"
                       "\n\t3. Generate graph in random_graph1.txt and random_graph2.txt"
                       "\n\t0. Exit";
    std::cout << menu;
}

void Console::print_menu_read() {
    std::string menu = "~ Menu - read ~"
                       "\n\t1. Get the number of vertices"
                       "\n\t2. The set of vertices"
                       "\n\t3. Check if there is an edge between 2 vertices"
                       "\n\t4. Get the in & out degree of a vertex"
                       "\n\t5. Get the set of outbound edges of a specified vertex"
                       "\n\t6. Get the set of inbound edges of a specified vertex"
                       "\n\t7. Get cost of edge"
                       "\n\t8. Modify cost of edge"
                       "\n\t9. Add edge"
                       "\n\t10. Remove edge"
                       "\n\t11. Add vertex"
                       "\n\t12. Remove vertex"
                       "\n\t13. Save"
                       "\n\t0. Exit";
    std::cout << menu;
}

void Console::handle_command(const std::string& command) {
    if (command == "0") {
        this->_unicorns_exist = false;
        return;
    }
    if (command == "1") {
        std::cout << "Input name of file: ";
        try {
            this->read_file();
            this->run_read();
        }
        catch (const ConsoleException &ce) {
            std::cout << ce.get_msg() << "\n";
        }

    }
    if (command == "2") {
        this->_file = "graph_random.txt";
        int x, y;
        std::cout << "Number of vertices = "; std::cin >> x;
        std::cout << "Number of edges = "; std::cin >> y;
        try {
            this->generate_graph(x, y);
            this->save_file();
        }catch (const GraphException &ge) {
            std::cout << ge.get_msg() << "\n";
        }
        return;
    }
    if (command == "3") {
        this->_file = "random_graph1.txt";
        this->generate_graph(7, 20);
        this->save_file();
        try{
            this->_file = "random_graph2.txt";
            this->generate_graph(6, 40);
        }catch (const GraphException &ge) {
            std::cout << ge.get_msg() << "\n";
        }
        return;
    }
    else{
        throw ConsoleException("Wrong command!");
    }


}

void Console::handle_command_read(const std::string& command) {
    if (command == "0"){
        this->_unicorns_exist = false;
        return;
    }
    if(command == "1"){
        int number = this->_graph.getNumberOfVertices();
        std::cout << "\nThe number of vertices is " << number << "\n";
        return;
    }
    if(command == "2"){
        auto vertices = this->_graph.parseVertices();
        std::cout << "The vertices are: ";
        for(auto it = vertices.first; it!= vertices.second; it++)
            std::cout << it->first << " ";
        return;
    }
    if(command == "3"){
        std::cout << "Input the 2 vertices:\n";
        int x, y;
        std::cout << "x= "; std::cin >> x;
        std::cout << "y= "; std::cin >> y;
        try{
            bool rez = this->_graph.isEdge(x, y);
            if (rez)
                cout << "There is an edge between them!\n";
            else
                cout << "There is not an edge between them!\n";
        }
        catch(const GraphException &ge){
            cout << ge.get_msg() << "\n";
        }
        return;
    }

    if(command == "4"){
        int x;
        std::cout << "Input the vertex x= "; std::cin >> x;
        try{
            int degreeIn, degreeOut;
            degreeIn = this->_graph.inDegree(x);
            degreeOut = this->_graph.outDegree(x);
            cout << "The in degree is " << degreeIn << " and the out degree is " << degreeOut << "\n";
        }catch(const GraphException& ge){
            cout << ge.get_msg() << "\n";
        }
        return;
    }

    if(command == "5"){
        int x;
        std::cout << "Input the vertex x= "; std::cin >> x;
        try{
            auto vertices_out = this->_graph.parseVertexOut(x);
            cout << "The vertices are: ";
            for(auto i = vertices_out.first; i < vertices_out.second; i++){
                cout << *i << " ";
            }
            cout << "\n";
        }catch(const GraphException& ge) {
            cout << ge.get_msg() << "\n";
        }
        return;
    }

    if(command == "6"){
        int x;
        std::cout << "Input the vertex x= "; std::cin >> x;
        try{
            auto vertices_in = this->_graph.parseVertexIn(x);
            cout << "The vertices are: ";
            for(auto i = vertices_in.first; i < vertices_in.second; i++){
                cout << *i << " ";
            }
            cout << "\n";
        }catch(const GraphException& ge) {
            cout << ge.get_msg() << "\n";
        }
        return;
    }

    if (command == "7"){
        std::cout << "Input the 2 vertices:\n";
        int x, y;
        std::cout << "x= "; std::cin >> x;
        std::cout << "y= "; std::cin >> y;
        try{
            int cost;
            cost = this->_graph.getCost(x, y);
            std::cout << "The cost of the edge is " << cost << "\n";
        }catch(const GraphException& ge) {
            cout << ge.get_msg() << "\n";
        }
        return;
    }

    if (command == "8"){
        std::cout << "Input the 2 vertices:\n";
        int x, y, cost;
        std::cout << "x= "; std::cin >> x;
        std::cout << "y= "; std::cin >> y;
        std::cout << "Input the cost = "; std::cin >> cost;
        try{
            this->_graph.setCost(x, y, cost);
            std::cout << "The cost has been modified!\n";
        }catch(const GraphException& ge) {
            cout << ge.get_msg() << "\n";
        }
        return;
    }

    if (command == "9"){
        std::cout << "Input the 2 vertices:\n";
        int x, y, cost;
        std::cout << "x= "; std::cin >> x;
        std::cout << "y= "; std::cin >> y;
        std::cout << "Input the cost = "; std::cin >> cost;
        try{
            this->_graph.addEdge(x, y, cost);
            std::cout << "The edge has been added!\n";
        }catch(const GraphException& ge) {
            cout << ge.get_msg() << "\n";
        }
        return;
    }

    if (command == "10"){
        std::cout << "Input the 2 vertices:\n";
        int x, y;
        std::cout << "x= "; std::cin >> x;
        std::cout << "y= "; std::cin >> y;
        try{
            this->_graph.removeEdge(x, y);
            std::cout << "The edge has been removed!\n";
        }catch(const GraphException& ge) {
            cout << ge.get_msg() << "\n";
        }
        return;
    }

    if (command == "11"){
        std::cout << "Input the vertex you want to add:\n";
        int x;
        std::cout << "x= "; std::cin >> x;
        try{
            this->_graph.addVertex(x);
            std::cout << "The vertex was added!\n";
        }catch(const GraphException& ge) {
            cout << ge.get_msg() << "\n";
        }
        return;
    }

    if (command == "12"){
        std::cout << "Input the vertex you want to remove:\n";
        int x;
        std::cout << "x= "; std::cin >> x;
        try{
            this->_graph.removeVertex(x);
            std::cout << "The vertex was removed!\n";
        }catch(const GraphException& ge) {
            cout << ge.get_msg() << "\n";
        }
        return;
    }

    if (command == "13"){
        this->save_file();
        return;
    }
    throw ConsoleException("\nWrong command!");

}

void Console::read_file() {
    std::string file;
    std::cin >> file;
    this->_file = file;
    std::ifstream myFile(file);
    if (myFile.is_open()) {
        if (file.find("_modif") != std::string::npos){
            cout << "Can't read from modified file!";
        }
        else{
            int nrV, nrE;
            myFile >> nrV >> nrE;
            this->_graph = Graph{nrV};

            for (int i = 0; i < nrE; ++i) {
                int v1, v2, cost;
                myFile >> v1 >> v2 >> cost;
                this->_graph.addEdgeNoCondition(v1, v2, cost);
            }
        }
        myFile.close();
    } else {
        throw ConsoleException("Unable to open file");
    }

}

void Console::save_file() {
    std::string fileName = this->_file;
    if (fileName.find("_modif") != std::string::npos or fileName.find("random") != std::string::npos) {
        // is string
    }
    else {
        fileName.erase(fileName.length() - 4);
        fileName += "_modif.txt";
    }
    ofstream myFile(fileName);

    auto vertices = this->_graph.parseVertices();
    for(auto it = vertices.first; it!= vertices.second; it++) {
        int vertex = it->first ;
        auto verticesOut = this->_graph.parseVertexOut(vertex);

        // check if it's isolated
        if (verticesOut.first == verticesOut.second){
            auto verticesIn = this->_graph.parseVertexIn(vertex);
            if(verticesIn.first == verticesIn.second){
                myFile << vertex << "\n";
                continue;
            }
        }

        // if it's not isolated
        for(auto i = verticesOut.first; i < verticesOut.second; i++){
            myFile << vertex << " " << *i << " " << this->_graph.getCost(vertex, *i) << "\n";
        }
    }
    myFile.close();

}

void Console::generate_graph(int nrV, int nrE) {
    if (nrE > nrV * nrV)
        throw GraphException("Data is not correct for" + this->_file + "!");

    this->_graph = Graph{nrV};
    int x, y, cost;
    for (int i = 0; i < nrE; i++) {
        x = rand() % nrV;
        y = rand() % nrV;
        cost = rand() % 300;
        if (this->_graph.isEdge(x, y)) {
            i--;
        }else {
            this->_graph.addEdge(x, y, cost);
        }
    }
}
